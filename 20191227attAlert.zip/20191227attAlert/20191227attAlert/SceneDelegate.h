//
//  SceneDelegate.h
//  20191227attAlert
//
//  Created by dongouc on 2019/12/27.
//  Copyright © 2019 dongouc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

